#!/bin/bash
#

echo "**** Installing required packages"
sudo dnf -y install httpd podman jq unzip

# set web server to port 8080
echo "**** Setting web server to port 8080"
sudo sed -i 's/^Listen 80$/Listen 8080/' /etc/httpd/conf/httpd.conf

echo "**** Starting web server"
sudo systemctl start httpd


exit 0
