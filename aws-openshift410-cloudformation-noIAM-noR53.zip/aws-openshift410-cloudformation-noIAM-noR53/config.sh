#!/bin/bash

###
# ocp details
###
cluster_name="CLUSTERNAME"
base_domain="BASEDOMAIN"

###
# registry info
###
registry_url="REGISTRYHOSTNAME:REGISTRYPORT"
local_auth_json="/ibm/security/auth/auth.json"
additional_trust_cert="/ibm/security/certs/ca.crt"

###
# AWS info
###
aws_region="REGION"
aws_private_subnets="PRIVATESUBNETID"
aws_vpc_id="VPCID"
aws_vpc_cidr="VPCCIDR"
aws_rhcos_ami_id="AMIID"

###
# ocp architecture
###
bootstrap_allowed_ssh_cidr="0.0.0.0/0"
bootstrap_subnet=$aws_private_subnets # TODO: this needs to be fixed for multiple private subnets
bootstrap_ignition_url="http://HOSTNAME:PORT/bootstrap.ign"
master_instance_type="m5.xlarge"
master_0_subnet=$aws_private_subnets # TODO: this needs to be fixed for multiple private subnets
master_1_subnet=$aws_private_subnets # TODO: this needs to be fixed for multiple private subnets
master_2_subnet=$aws_private_subnets # TODO: this needs to be fixed for multiple private subnets
worker_subnet=$aws_private_subnets # TODO: this needs to be fixed for multiple private subnets
worker_count=3
worker_instance_type="m5.4xlarge"
